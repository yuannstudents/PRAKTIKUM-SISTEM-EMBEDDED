/* ================================================================
 * main.c — Blue Pill STM32F103C8T6 (CHIP CLONE OK)
 * SEMUA dalam 1 file, tidak perlu stm32f1xx_it.c terpisah
 * ================================================================
 *
 * WIRING:
 *   PA1  ──[220Ω]──► LED1 ──► GND
 *   PA2  ──[220Ω]──► LED2 ──► GND
 *   PB12 ──────────── BTN1 ── GND  (pull-up internal) ← PINDAH DARI PC13
 *   PC14 ──────────── BTN2 ── GND  (pull-up internal) ← tetap
 *   PA9  (TX) ──────────────────── FTDI RX
 *   PA10 (RX) ◄─────────────────── FTDI TX
 *   GND  ────────────────────────── FTDI GND
 *
 * KENAPA PC13 TIDAK DIPAKAI UNTUK BTN1:
 *   PC13 pada Blue Pill terhubung ke kapasitor filter dan
 *   resistor 10kΩ untuk oscillator RTC 32kHz. Akibatnya pin
 *   sangat lambat merespons dan tidak cocok sebagai input button.
 *   PC14 tidak punya masalah ini sehingga BTN2 tetap di PC14.
 *
 * PERILAKU:
 *   Tekan BTN1 (PB12) → LED1 (PA1) nyala + kirim "BTN1_PRESS\n"
 *   Lepas BTN1 (PB12) → LED1 (PA1) mati  + kirim "BTN1_RELEASE\n"
 *   Tekan BTN2 (PC14) → LED2 (PA2) nyala + kirim "BTN2_PRESS\n"
 *   Lepas BTN2 (PC14) → LED2 (PA2) mati  + kirim "BTN2_RELEASE\n"
 *
 * PERINTAH DARI PYTHON:
 *   L1_ON / L1_OFF → Kontrol LED1
 *   L2_ON / L2_OFF → Kontrol LED2
 * ================================================================ */

#include "stm32f1xx_hal.h"
#include <string.h>

/* ── Pin ─────────────────────────────────────────────────────── */
#define LED1_PIN    GPIO_PIN_1
#define LED2_PIN    GPIO_PIN_2
#define LED_PORT    GPIOA

#define BTN1_PIN    GPIO_PIN_12   /* PB12 — stabil, tidak ada RC filter */
#define BTN1_PORT   GPIOB

#define BTN2_PIN    GPIO_PIN_14   /* PC14 — oke untuk input */
#define BTN2_PORT   GPIOC

/* ── UART ────────────────────────────────────────────────────── */
UART_HandleTypeDef huart1;
static uint8_t rxByte;
static char    rxBuffer[32];
static uint8_t rxIndex = 0;

/* ── Prototypes ──────────────────────────────────────────────── */
static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void UART_Print(const char *str);
static void ProcessCommand(char *cmd);
void        Error_Handler(void);

/* ================================================================
 * MAIN
 * ================================================================ */
int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_USART1_UART_Init();

    HAL_UART_Receive_IT(&huart1, &rxByte, 1);

    /* Blink test — LED1 & LED2 bergantian, tanda program berjalan */
    HAL_GPIO_WritePin(LED_PORT, LED1_PIN, GPIO_PIN_SET);
    HAL_Delay(150);
    HAL_GPIO_WritePin(LED_PORT, LED1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LED_PORT, LED2_PIN, GPIO_PIN_SET);
    HAL_Delay(150);
    HAL_GPIO_WritePin(LED_PORT, LED2_PIN, GPIO_PIN_RESET);

    HAL_Delay(50);
    UART_Print("READY\n");

    GPIO_PinState lastB1 = GPIO_PIN_SET;
    GPIO_PinState lastB2 = GPIO_PIN_SET;

    while (1)
    {
        GPIO_PinState b1 = HAL_GPIO_ReadPin(BTN1_PORT, BTN1_PIN);
        GPIO_PinState b2 = HAL_GPIO_ReadPin(BTN2_PORT, BTN2_PIN);

        /* ── BTN1 (PB12) → LED1 (PA1) ──────────────────────── */
        if (b1 != lastB1)
        {
            HAL_Delay(20);
            b1 = HAL_GPIO_ReadPin(BTN1_PORT, BTN1_PIN);
            if (b1 != lastB1)
            {
                lastB1 = b1;
                if (b1 == GPIO_PIN_RESET)
                {
                    HAL_GPIO_WritePin(LED_PORT, LED1_PIN, GPIO_PIN_SET);
                    UART_Print("BTN1_PRESS\n");
                }
                else
                {
                    HAL_GPIO_WritePin(LED_PORT, LED1_PIN, GPIO_PIN_RESET);
                    UART_Print("BTN1_RELEASE\n");
                }
            }
        }

        /* ── BTN2 (PC14) → LED2 (PA2) ──────────────────────── */
        if (b2 != lastB2)
        {
            HAL_Delay(20);
            b2 = HAL_GPIO_ReadPin(BTN2_PORT, BTN2_PIN);
            if (b2 != lastB2)
            {
                lastB2 = b2;
                if (b2 == GPIO_PIN_RESET)
                {
                    HAL_GPIO_WritePin(LED_PORT, LED2_PIN, GPIO_PIN_SET);
                    UART_Print("BTN2_PRESS\n");
                }
                else
                {
                    HAL_GPIO_WritePin(LED_PORT, LED2_PIN, GPIO_PIN_RESET);
                    UART_Print("BTN2_RELEASE\n");
                }
            }
        }

        HAL_Delay(5);
    }
}

/* ================================================================
 * UART Print
 * ================================================================ */
static void UART_Print(const char *str)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)str, strlen(str), 100);
}

/* ================================================================
 * Proses perintah dari Python
 * ================================================================ */
static void ProcessCommand(char *cmd)
{
    if      (strcmp(cmd, "L1_ON")  == 0) HAL_GPIO_WritePin(LED_PORT, LED1_PIN, GPIO_PIN_SET);
    else if (strcmp(cmd, "L1_OFF") == 0) HAL_GPIO_WritePin(LED_PORT, LED1_PIN, GPIO_PIN_RESET);
    else if (strcmp(cmd, "L2_ON")  == 0) HAL_GPIO_WritePin(LED_PORT, LED2_PIN, GPIO_PIN_SET);
    else if (strcmp(cmd, "L2_OFF") == 0) HAL_GPIO_WritePin(LED_PORT, LED2_PIN, GPIO_PIN_RESET);
    UART_Print("ACK\n");
}

/* ================================================================
 * UART RX Interrupt Callback
 * ================================================================ */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        if (rxByte == '\n' || rxByte == '\r')
        {
            rxBuffer[rxIndex] = '\0';
            if (rxIndex > 0) ProcessCommand(rxBuffer);
            rxIndex = 0;
        }
        else if (rxIndex < 31)
        {
            rxBuffer[rxIndex++] = (char)rxByte;
        }
        HAL_UART_Receive_IT(&huart1, &rxByte, 1);
    }
}

/* ================================================================
 * IRQ Handlers — langsung di main.c
 * ================================================================ */
void SysTick_Handler(void)    { HAL_IncTick(); }
void USART1_IRQHandler(void)  { HAL_UART_IRQHandler(&huart1); }

/* ================================================================
 * GPIO Init
 * ================================================================ */
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_AFIO_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* Disable JTAG — bebaskan PB3/PB4/PA15, SWD tetap aktif */
    __HAL_AFIO_REMAP_SWJ_NOJTAG();

    /* LED mati saat startup */
    HAL_GPIO_WritePin(LED_PORT, LED1_PIN | LED2_PIN, GPIO_PIN_RESET);

    /* PA1, PA2 → LED OUTPUT */
    GPIO_InitStruct.Pin   = LED1_PIN | LED2_PIN;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LED_PORT, &GPIO_InitStruct);

    /* PB12 → BTN1 INPUT PULL-UP */
    GPIO_InitStruct.Pin   = BTN1_PIN;
    GPIO_InitStruct.Mode  = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull  = GPIO_PULLUP;
    HAL_GPIO_Init(BTN1_PORT, &GPIO_InitStruct);

    /* PC14 → BTN2 INPUT PULL-UP */
    GPIO_InitStruct.Pin   = BTN2_PIN;
    GPIO_InitStruct.Mode  = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull  = GPIO_PULLUP;
    HAL_GPIO_Init(BTN2_PORT, &GPIO_InitStruct);
}

/* ================================================================
 * USART1 Init — PA9(TX) AF_PP, PA10(RX) INPUT, 115200 8N1
 * ================================================================ */
static void MX_USART1_UART_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PA9 TX */
    GPIO_InitStruct.Pin   = GPIO_PIN_9;
    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* PA10 RX */
    GPIO_InitStruct.Pin   = GPIO_PIN_10;
    GPIO_InitStruct.Mode  = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) Error_Handler();

    HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
}

/* ================================================================
 * System Clock — HSE 8MHz → PLL 72MHz
 * ================================================================ */
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInit = {0};
    RCC_ClkInitTypeDef RCC_ClkInit = {0};

    RCC_OscInit.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInit.HSEState       = RCC_HSE_ON;
    RCC_OscInit.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInit.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInit.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInit.PLL.PLLMUL     = RCC_PLL_MUL9;
    if (HAL_RCC_OscConfig(&RCC_OscInit) != HAL_OK) Error_Handler();

    RCC_ClkInit.ClockType      = RCC_CLOCKTYPE_HCLK  | RCC_CLOCKTYPE_SYSCLK
                               | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInit.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInit.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInit.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInit.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInit, FLASH_LATENCY_2) != HAL_OK) Error_Handler();
}

/* ================================================================
 * Error Handler
 * ================================================================ */
void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}