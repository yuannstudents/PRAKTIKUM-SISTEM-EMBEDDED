#!/usr/bin/env python3
"""
STM32 Blue Pill — LED & Push Button Controller
Instalasi : pip install pyserial
Jalankan  : python stm32_controller.py

Protokol:
  Kirim  → L1_ON / L1_OFF / L2_ON / L2_OFF
  Terima ← READY / ACK / BTN1_PRESS / BTN1_RELEASE / BTN2_PRESS / BTN2_RELEASE
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import serial
import serial.tools.list_ports
import threading
import queue
import time
from datetime import datetime

C = {
    "bg":       "#0e0e16", "panel":  "#16161f", "card":   "#1c1c28",
    "border":   "#28283c", "accent": "#00d4ff", "green":  "#00ff88",
    "red":      "#ff3355", "yellow": "#ffc820", "purple": "#bb86fc",
    "white":    "#e8e8f4", "gray":   "#50506a", "gray2":  "#2a2a3e",
    "led_on":   "#ffc820", "led_ring":"#ff9500","led_off": "#252515",
    "btn_on":   "#ff3355", "btn_off": "#1c1c28","log_bg":  "#080810",
}


class STM32App:
    def __init__(self, root):
        self.root    = root
        self.root.title("STM32 Blue Pill  —  LED & Button Controller")
        self.root.configure(bg=C["bg"])
        self.root.resizable(False, False)

        self.ser      = None
        self.running  = False
        self.rxq      = queue.Queue()
        self.led_st   = [False, False]
        self.btn_cnt  = [0, 0]

        self._lcanvas  = [None, None]
        self._loval    = [None, None]
        self._lring    = [None, None]
        self._llbl     = [None, None]
        self._bcanvas  = [None, None]
        self._bcnt_lbl = [None, None]

        self._build_ui()
        self._refresh_ports()
        self._poll_queue()

    # ─────────────────────────────────────────
    def _build_ui(self):
        tk.Canvas(self.root, height=3, bg=C["accent"],
                  highlightthickness=0).pack(fill="x")

        hf = tk.Frame(self.root, bg=C["bg"])
        hf.pack(fill="x", padx=18, pady=(12, 4))
        tk.Label(hf, text="STM32", font=("Courier New", 20, "bold"),
                 bg=C["bg"], fg=C["accent"]).pack(side="left")
        tk.Label(hf, text="  Blue Pill  |  LED & Button Controller",
                 font=("Courier New", 10), bg=C["bg"], fg=C["white"]
                 ).pack(side="left", pady=5)
        self._dot = tk.Label(hf, text="● OFFLINE",
                             font=("Courier New", 9, "bold"),
                             bg=C["bg"], fg=C["red"])
        self._dot.pack(side="right")

        tk.Canvas(self.root, height=1, bg=C["border"],
                  highlightthickness=0).pack(fill="x")

        body = tk.Frame(self.root, bg=C["bg"], padx=14, pady=12)
        body.pack()

        left = tk.Frame(body, bg=C["bg"])
        left.pack(side="left", fill="y", padx=(0, 10))
        right = tk.Frame(body, bg=C["bg"])
        right.pack(side="left", fill="both", expand=True)

        self._build_conn(left)
        self._build_leds(left)
        self._build_cmds(left)
        self._build_btns(right)
        self._build_log(right)

    # ── Koneksi ───────────────────────────────
    def _build_conn(self, parent):
        f = self._frame(parent, "⚡  KONEKSI SERIAL")
        f.pack(fill="x", pady=(0, 8))

        row = tk.Frame(f, bg=C["panel"])
        row.pack(padx=10, pady=8, fill="x")

        tk.Label(row, text="PORT", font=("Courier New", 7, "bold"),
                 bg=C["panel"], fg=C["gray"]).grid(row=0, column=0, sticky="w")
        self._port_v = tk.StringVar()
        self._combo  = ttk.Combobox(row, textvariable=self._port_v,
                                    width=12, font=("Courier New", 9))
        self._combo.grid(row=1, column=0, padx=(0, 8), pady=2)

        tk.Label(row, text="BAUD", font=("Courier New", 7, "bold"),
                 bg=C["panel"], fg=C["gray"]).grid(row=0, column=1, sticky="w")
        self._baud_v = tk.StringVar(value="115200")
        ttk.Combobox(row, textvariable=self._baud_v, width=8,
                     font=("Courier New", 9),
                     values=["9600","19200","57600","115200"]
                     ).grid(row=1, column=1)

        br = tk.Frame(f, bg=C["panel"])
        br.pack(padx=10, pady=(0, 10), fill="x")
        tk.Button(br, text="↺  Refresh", command=self._refresh_ports,
                  font=("Courier New", 8), bg=C["card"], fg=C["gray"],
                  relief="flat", cursor="hand2", padx=8, pady=4
                  ).pack(side="left", padx=(0, 8))
        self._btn_conn = tk.Button(br, text="CONNECT",
                                   command=self._toggle_conn,
                                   font=("Courier New", 9, "bold"),
                                   bg=C["accent"], fg=C["bg"],
                                   relief="flat", cursor="hand2",
                                   padx=14, pady=4)
        self._btn_conn.pack(side="left")

    # ── LED ───────────────────────────────────
    def _build_leds(self, parent):
        f = self._frame(parent, "💡  KONTROL LED")
        f.pack(fill="x", pady=(0, 8))

        # Info box
        info = tk.Frame(f, bg="#1a2a1a", highlightbackground="#2a4a2a",
                        highlightthickness=1)
        info.pack(fill="x", padx=10, pady=(8, 4))
        tk.Label(info,
                 text="  BTN1 tekan → LED1 nyala  |  BTN2 tekan → LED2 nyala",
                 font=("Courier New", 7), bg="#1a2a1a", fg=C["green"],
                 pady=4).pack()

        row = tk.Frame(f, bg=C["panel"])
        row.pack(padx=10, pady=(4, 10))

        for i in range(2):
            card = tk.Frame(row, bg=C["card"], padx=12, pady=10,
                            highlightbackground=C["border"], highlightthickness=1)
            card.grid(row=0, column=i * 2)
            if i == 0:
                tk.Frame(row, width=14, bg=C["panel"]).grid(row=0, column=1)

            tk.Label(card, text=f"LED {i+1}",
                     font=("Courier New", 9, "bold"),
                     bg=C["card"], fg=C["white"]).pack()

            c = tk.Canvas(card, width=60, height=60,
                          bg=C["card"], highlightthickness=0)
            c.pack(pady=5)
            ring = c.create_oval(4, 4, 56, 56,
                                 fill=C["led_off"], outline="", width=0)
            oval = c.create_oval(12, 12, 48, 48,
                                 fill=C["led_off"], outline=C["gray"], width=1)
            self._lcanvas[i] = c
            self._loval[i]   = oval
            self._lring[i]   = ring

            lbl = tk.Label(card, text="OFF",
                           font=("Courier New", 8, "bold"),
                           bg=C["card"], fg=C["gray"])
            lbl.pack()
            self._llbl[i] = lbl

            br2 = tk.Frame(card, bg=C["card"])
            br2.pack(pady=(5, 0))
            tk.Button(br2, text="ON",
                      command=lambda n=i: self._send(f"L{n+1}_ON"),
                      font=("Courier New", 8, "bold"),
                      bg="#152515", fg=C["green"],
                      relief="flat", cursor="hand2",
                      width=5, pady=3).pack(side="left", padx=1)
            tk.Button(br2, text="OFF",
                      command=lambda n=i: self._send(f"L{n+1}_OFF"),
                      font=("Courier New", 8, "bold"),
                      bg="#251520", fg=C["red"],
                      relief="flat", cursor="hand2",
                      width=5, pady=3).pack(side="left", padx=1)

    # ── Tombol Cepat ──────────────────────────
    def _build_cmds(self, parent):
        f = self._frame(parent, "⌨  PERINTAH CEPAT")
        f.pack(fill="x", pady=(0, 8))

        bf = tk.Frame(f, bg=C["panel"])
        bf.pack(padx=10, pady=8)

        btns = [
            ("ALL ON",   self._all_on,  C["green"], "#152515"),
            ("ALL OFF",  self._all_off, C["red"],   "#251520"),
            ("TOGGLE 1", lambda: self._toggle(0),   C["accent"], "#052030"),
            ("TOGGLE 2", lambda: self._toggle(1),   C["accent"], "#052030"),
        ]
        for i, (lbl, cmd, fg, bg) in enumerate(btns):
            r, c = divmod(i, 2)
            tk.Button(bf, text=lbl, command=cmd,
                      font=("Courier New", 8, "bold"),
                      bg=bg, fg=fg, relief="flat", cursor="hand2",
                      width=9, pady=5).grid(row=r, column=c, padx=3, pady=3)

        # Custom command
        tk.Canvas(f, height=1, bg=C["border"],
                  highlightthickness=0).pack(fill="x", padx=10)
        cf = tk.Frame(f, bg=C["panel"])
        cf.pack(padx=10, pady=8, fill="x")
        tk.Label(cf, text="CMD:", font=("Courier New", 8),
                 bg=C["panel"], fg=C["gray"]).pack(side="left")
        self._cv = tk.StringVar()
        e = tk.Entry(cf, textvariable=self._cv,
                     font=("Courier New", 9), bg=C["card"], fg=C["white"],
                     insertbackground=C["accent"], relief="flat", width=12)
        e.pack(side="left", padx=6)
        e.bind("<Return>", lambda _: self._send_custom())
        tk.Button(cf, text="→", command=self._send_custom,
                  font=("Courier New", 11, "bold"),
                  bg="#ff8c00", fg=C["white"],
                  relief="flat", cursor="hand2", padx=8).pack(side="left")

    # ── Push Button Monitor ───────────────────
    def _build_btns(self, parent):
        f = self._frame(parent, "🔘  PUSH BUTTON MONITOR")
        f.pack(fill="x", pady=(0, 8))

        row = tk.Frame(f, bg=C["panel"])
        row.pack(padx=10, pady=10)

        for i in range(2):
            card = tk.Frame(row, bg=C["card"], padx=12, pady=10,
                            highlightbackground=C["border"], highlightthickness=1)
            card.grid(row=0, column=i * 2)
            if i == 0:
                tk.Frame(row, width=14, bg=C["panel"]).grid(row=0, column=1)

            tk.Label(card, text=f"BUTTON {i+1}",
                     font=("Courier New", 9, "bold"),
                     bg=C["card"], fg=C["white"]).pack()

            c = tk.Canvas(card, width=80, height=80,
                          bg=C["card"], highlightthickness=0)
            c.pack(pady=5)
            c.create_oval(4, 4, 76, 76, fill=C["btn_off"],
                          outline=C["border"], width=1, tags="ring")
            c.create_oval(14, 14, 66, 66, fill=C["btn_off"],
                          outline=C["gray"], width=2, tags="circle")
            c.create_text(40, 40, text="IDLE", fill=C["gray"],
                          font=("Courier New", 9, "bold"), tags="txt")
            self._bcanvas[i] = c

            # LED indicator kecil di samping label
            tk.Label(card, text=f"→ LED{i+1}",
                     font=("Courier New", 7),
                     bg=C["card"], fg=C["gray"]).pack()

            cnt = tk.Label(card, text="Tekan: 0",
                           font=("Courier New", 7),
                           bg=C["card"], fg=C["gray"])
            cnt.pack()
            self._bcnt_lbl[i] = cnt

            tk.Button(card, text="Reset",
                      command=lambda n=i: self._reset_cnt(n),
                      font=("Courier New", 7), bg=C["border"], fg=C["gray"],
                      relief="flat", cursor="hand2").pack(pady=(3, 0))

    # ── Log ───────────────────────────────────
    def _build_log(self, parent):
        f = self._frame(parent, "📋  LOG UART")
        f.pack(fill="both", expand=True)

        ff = tk.Frame(f, bg=C["panel"])
        ff.pack(fill="x", padx=10, pady=(6, 2))
        self._fv = {}
        for name, color in [("RX", C["green"]), ("TX", C["accent"]),
                             ("SYS", C["yellow"]), ("ERR", C["red"]),
                             ("ACK", C["purple"])]:
            v = tk.BooleanVar(value=True)
            self._fv[name.lower()] = v
            tk.Checkbutton(ff, text=name, variable=v,
                           font=("Courier New", 7, "bold"),
                           bg=C["panel"], fg=color,
                           selectcolor=C["card"],
                           activebackground=C["panel"],
                           relief="flat").pack(side="left", padx=3)
        tk.Button(ff, text="🗑 Clear",
                  command=lambda: self.log.delete("1.0", "end"),
                  font=("Courier New", 7), bg=C["card"], fg=C["gray"],
                  relief="flat", cursor="hand2").pack(side="right", padx=6)

        self.log = scrolledtext.ScrolledText(
            f, width=42, height=22,
            bg=C["log_bg"], fg=C["green"],
            font=("Courier New", 8),
            insertbackground=C["white"],
            relief="flat", wrap="word", padx=8, pady=6)
        self.log.pack(fill="both", expand=True, padx=10, pady=(2, 10))

        for tag, color in [("rx", C["green"]), ("tx", C["accent"]),
                           ("sys", C["yellow"]), ("err", C["red"]),
                           ("ack", C["purple"])]:
            self.log.tag_config(tag, foreground=color)

    # ─────────────────────────────────────────
    def _frame(self, parent, title):
        f = tk.Frame(parent, bg=C["panel"],
                     highlightbackground=C["border"], highlightthickness=1)
        tb = tk.Frame(f, bg=C["gray2"])
        tb.pack(fill="x")
        tk.Label(tb, text=title, font=("Courier New", 8, "bold"),
                 bg=C["gray2"], fg=C["accent"],
                 padx=10, pady=5).pack(side="left")
        return f

    # ─────────────────────────────────────────
    #  KONEKSI
    # ─────────────────────────────────────────
    def _refresh_ports(self):
        ports_info = serial.tools.list_ports.comports()
        ports = [p.device for p in ports_info]
        self._combo["values"] = ports
        if ports:
            ftdi = [p.device for p in ports_info
                    if any(k in (p.description or "").upper()
                           for k in ("USB", "FTDI", "COM"))]
            self._port_v.set(ftdi[0] if ftdi else ports[0])

    def _toggle_conn(self):
        if self.ser and self.ser.is_open:
            self._disconnect()
        else:
            self._connect()

    def _connect(self):
        port = self._port_v.get().strip()
        if not port:
            messagebox.showwarning("Error", "Pilih port dulu!")
            return
        try:
            self.ser = serial.Serial(port, int(self._baud_v.get()),
                                     timeout=0.1)
            self.running = True
            self._dot.config(text=f"● ONLINE  {port}", fg=C["green"])
            self._btn_conn.config(text="DISCONNECT",
                                  bg=C["red"], fg=C["white"])
            self._log(f"Terhubung ke {port}", "sys")
            threading.Thread(target=self._reader, daemon=True).start()
        except serial.SerialException as e:
            messagebox.showerror("Gagal", str(e))

    def _disconnect(self):
        self.running = False
        time.sleep(0.15)
        try:
            if self.ser: self.ser.close()
        except: pass
        self._dot.config(text="● OFFLINE", fg=C["red"])
        self._btn_conn.config(text="CONNECT", bg=C["accent"], fg=C["bg"])
        self._log("Koneksi ditutup.", "sys")

    # ─────────────────────────────────────────
    #  KIRIM
    # ─────────────────────────────────────────
    def _send(self, cmd):
        if not self.ser or not self.ser.is_open:
            self._log("Belum konek!", "err"); return
        try:
            self.ser.write((cmd + "\n").encode())
            self._log(f"TX ►  {cmd}", "tx")
        except Exception as e:
            self._log(f"Gagal: {e}", "err")

    def _all_on(self):
        self._send("L1_ON")
        self.root.after(60, lambda: self._send("L2_ON"))

    def _all_off(self):
        self._send("L1_OFF")
        self.root.after(60, lambda: self._send("L2_OFF"))

    def _toggle(self, idx):
        self._send(f"L{idx+1}_{'OFF' if self.led_st[idx] else 'ON'}")

    def _send_custom(self):
        cmd = self._cv.get().strip()
        if cmd:
            self._send(cmd)
            self._cv.set("")

    # ─────────────────────────────────────────
    #  BACA SERIAL
    # ─────────────────────────────────────────
    def _reader(self):
        buf = ""
        while self.running:
            try:
                if self.ser and self.ser.in_waiting:
                    buf += self.ser.read(
                        self.ser.in_waiting).decode("ascii", errors="replace")
                    while "\n" in buf:
                        line, buf = buf.split("\n", 1)
                        line = line.strip()
                        if line: self.rxq.put(line)
                else:
                    time.sleep(0.01)
            except: break

    def _poll_queue(self):
        try:
            while True:
                self._handle(self.rxq.get_nowait())
        except queue.Empty:
            pass
        self.root.after(20, self._poll_queue)

    def _handle(self, line):
        if line == "READY":
            self._log("RX ◄  READY  ✓  STM32 siap!", "sys")
        elif line == "ACK":
            self._log("RX ◄  ACK", "ack")
        elif line == "BTN1_PRESS":
            self._upd_btn(0, True)
            self._upd_led(0, True)    # LED1 nyala saat BTN1 tekan
            self._log("RX ◄  BTN1_PRESS  →  LED1 ON", "rx")
        elif line == "BTN1_RELEASE":
            self._upd_btn(0, False)
            self._upd_led(0, False)   # LED1 mati saat BTN1 lepas
            self._log("RX ◄  BTN1_RELEASE  →  LED1 OFF", "rx")
        elif line == "BTN2_PRESS":
            self._upd_btn(1, True)
            self._upd_led(1, True)    # LED2 nyala saat BTN2 tekan
            self._log("RX ◄  BTN2_PRESS  →  LED2 ON", "rx")
        elif line == "BTN2_RELEASE":
            self._upd_btn(1, False)
            self._upd_led(1, False)   # LED2 mati saat BTN2 lepas
            self._log("RX ◄  BTN2_RELEASE  →  LED2 OFF", "rx")
        else:
            self._log(f"RX ◄  {line}", "rx")

    # ─────────────────────────────────────────
    #  UPDATE VISUAL
    # ─────────────────────────────────────────
    def _upd_led(self, idx, on):
        self.led_st[idx] = on
        c, o, r, l = (self._lcanvas[idx], self._loval[idx],
                      self._lring[idx],   self._llbl[idx])
        if on:
            c.itemconfig(r, fill="#2a2000", outline=C["led_ring"], width=3)
            c.itemconfig(o, fill=C["led_on"],  outline=C["led_ring"], width=2)
            l.config(text="ON  ●", fg=C["led_on"])
        else:
            c.itemconfig(r, fill=C["led_off"], outline="", width=0)
            c.itemconfig(o, fill=C["led_off"], outline=C["gray"],    width=1)
            l.config(text="OFF", fg=C["gray"])

    def _upd_btn(self, idx, pressed):
        c = self._bcanvas[idx]
        if pressed:
            c.itemconfig("ring",   fill="#280010")
            c.itemconfig("circle", fill=C["btn_on"],
                         outline=C["red"], width=2)
            c.itemconfig("txt",    text="TEKAN", fill=C["white"])
            self.btn_cnt[idx] += 1
            self._bcnt_lbl[idx].config(
                text=f"Tekan: {self.btn_cnt[idx]}", fg=C["red"])
        else:
            c.itemconfig("ring",   fill=C["btn_off"])
            c.itemconfig("circle", fill=C["btn_off"],
                         outline=C["gray"], width=2)
            c.itemconfig("txt",    text="IDLE", fill=C["gray"])
            self._bcnt_lbl[idx].config(
                text=f"Tekan: {self.btn_cnt[idx]}", fg=C["gray"])

    def _reset_cnt(self, idx):
        self.btn_cnt[idx] = 0
        self._bcnt_lbl[idx].config(text="Tekan: 0", fg=C["gray"])

    # ─────────────────────────────────────────
    #  LOG
    # ─────────────────────────────────────────
    def _log(self, msg, tag="sys"):
        if not self._fv.get(tag, tk.BooleanVar(value=True)).get():
            return
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        self.log.insert("end", f"[{ts}]  {msg}\n", tag)
        self.log.see("end")
        if int(self.log.index("end-1c").split(".")[0]) > 500:
            self.log.delete("1.0", "50.0")


# ─────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("780x720")

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("TCombobox",
                    fieldbackground="#1c1c28", background="#1c1c28",
                    foreground="#e8e8f4", selectbackground="#00d4ff",
                    bordercolor="#28283c", arrowcolor="#00d4ff")

    app = STM32App(root)

    def on_close():
        app.running = False
        if app.ser and app.ser.is_open:
            try: app.ser.close()
            except: pass
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()